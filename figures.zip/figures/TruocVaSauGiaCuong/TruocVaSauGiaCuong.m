clear all
pt=[4*4 6*6 8*8 10*10 12*12];
wcTruocGC = [	0.897619	0.966800	0.988415	0.997746	1.002601]
plot(pt,wcTruocGC,'-.*r','LineWidth',1.5);
% plot(pt,wcTruocGC,'-.*r');
hold on;

wcSauGC = [	0.012817	0.012813	0.012796	0.012785	0.012777]
plot(pt,wcSauGC,'-vb','LineWidth',1.5);
% plot(pt,wcSauGC,'-vb');
ylim([-0.1 1.25])