% Ex1
Number of element in x-axis (8,12,16,20,24,...) = 4
Number of element in y-axis (8,12,16,20,24,...) = 4
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.601005071174746e-004
wcss =  (1,1)      0.071627368324149
 % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %    
Number of element in x-axis (8,12,16,20,24,...) = 6
Number of element in y-axis (8,12,16,20,24,...) = 6
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.581419254003082e-004
wcss =   (1,1)      0.071322460913967
Elapsed time is 9.314193 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Number of element in x-axis (8,12,16,20,24,...) = 8
Number of element in y-axis (8,12,16,20,24,...) = 8
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =  (1,1)       4.571908153443750e-004
wcss =   (1,1)      0.071174394330168
Elapsed time is 7.368704 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Number of element in x-axis (8,12,16,20,24,...) = 10
Number of element in y-axis (8,12,16,20,24,...) = 10
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.567244888741382e-004
wcss =   (1,1)      0.071101797718501
Elapsed time is 8.984839 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 12
Number of element in y-axis (8,12,16,20,24,...) = 12
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.564708664854676e-004
wcss =   (1,1)      0.071062314379606
Elapsed time is 23.361834 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 16
Number of element in y-axis (8,12,16,20,24,...) = 16
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.562248533739519e-004
wcss =   (1,1)      0.071024015635139
Elapsed time is 9.981180 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 32
Number of element in y-axis (8,12,16,20,24,...) = 32
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.560067691842005e-004
wcss =   (1,1)      0.070990064799738
Elapsed time is 21.506900 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 64
Number of element in y-axis (8,12,16,20,24,...) = 64
Option (1,2 or 3) = 1
plate is simply Supported at all the edges
w_cn =   (1,1)       4.559605122913885e-004
wcss =   (1,1)      0.070982863635106
Elapsed time is 104.038682 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Ex2
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 4
Number of element in y-axis (8,12,16,20,24,...) = 4
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.613880013944021
wcss =   (1,1)      0.012816736438857
Elapsed time is 6.644293 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 6
Number of element in y-axis (8,12,16,20,24,...) = 6
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.613680767781569
wcss =   (1,1)      0.012812576528951
Elapsed time is 4.787618 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 8
Number of element in y-axis (8,12,16,20,24,...) = 8
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.612890033973792
wcss =   (1,1)      0.012796067395933
Elapsed time is 5.371289 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 10
Number of element in y-axis (8,12,16,20,24,...) = 10
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.612336106156359
wcss =   (1,1)      0.012784502356054
Elapsed time is 7.185635 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 12
Number of element in y-axis (8,12,16,20,24,...) = 12
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.611974843830243
wcss =   (1,1)      0.012776959833225
Elapsed time is 7.963168 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 16
Number of element in y-axis (8,12,16,20,24,...) = 16
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.611570292827418
wcss =   (1,1)      0.012768513518862
Elapsed time is 10.807860 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 32
Number of element in y-axis (8,12,16,20,24,...) = 32
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.611153109196306
wcss =   (1,1)      0.012759803457408
Elapsed time is 19.653879 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 50
Number of element in y-axis (8,12,16,20,24,...) = 50
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.611078678808661
wcss =   (1,1)      0.012758249481648
Elapsed time is 52.812233 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 64
Number of element in y-axis (8,12,16,20,24,...) = 64
Option (1,2 or 3) = 2
plate is simply Supported at all the edges
w_cn =   (1,1)      0.611060762759122
wcss =   (1,1)      0.012757875426002
Elapsed time is 104.113805 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Ex3
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 4
Number of element in y-axis (8,12,16,20,24,...) = 4
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn =   (1,1)     10.569771887710228
wcss =   (1,1)      0.105697718877102
Elapsed time is 5.811068 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 6
Number of element in y-axis (8,12,16,20,24,...) = 6
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn =   (1,1)     11.654709948411140
wcss =   (1,1)      0.116547099484111
Elapsed time is 8.682193 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 8
Number of element in y-axis (8,12,16,20,24,...) = 8
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn =   (1,1)     12.081219998962856
wcss =   (1,1)      0.120812199989629
Elapsed time is 5.872079 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 16
Number of element in y-axis (8,12,16,20,24,...) = 16
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn =   (1,1)     12.512517244054443
wcss =   (1,1)      0.125125172440544
Elapsed time is 9.818106 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 32
Number of element in y-axis (8,12,16,20,24,...) = 32
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn=  (1,1)     12.619313302387830
wcss =   (1,1)      0.126193133023878
Elapsed time is 19.676838 seconds.
Number of element in x-axis (8,12,16,20,24,...) = 50
Number of element in y-axis (8,12,16,20,24,...) = 50
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn =   (1,1)     12.639589797129917
wcss =   (1,1)      0.126395897971299
Elapsed time is 60.759142 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 64
Number of element in y-axis (8,12,16,20,24,...) = 64
Option (1,2 or 3) = 3
plate is clamped at all the edges
w_cn =   (1,1)     12.644963030282579
wcss =   (1,1)      0.126449630302826
Elapsed time is 108.087083 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 4
Number of element in y-axis (8,12,16,20,24,...) = 4
Option (1,2,3 or 4) = 4
plate is simply Supported at all the edges

w_cn =   (1,1)     42.993034051321324
wcss =   (1,1)      0.897619035684745

Elapsed time is 5.134098 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 6
Number of element in y-axis (8,12,16,20,24,...) = 6
Option (1,2,3 or 4) = 4

w_cn =   (1,1)     46.306585072327771
wcss =   (1,1)      0.966800160901857

Elapsed time is 6.170678 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 8
Number of element in y-axis (8,12,16,20,24,...) = 8
Option (1,2,3 or 4) = 4

w_cn =   (1,1)     47.341868217314833
wcss =   (1,1)      0.988415054541479

Elapsed time is 4.918349 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 10
Number of element in y-axis (8,12,16,20,24,...) = 10
Option (1,2,3 or 4) = 4

w_cn =   (1,1)     47.788786740240177
wcss =   (1,1)      0.997745928308123
 
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 12
Number of element in y-axis (8,12,16,20,24,...) = 12
Option (1,2,3 or 4) = 4

w_cn =   (1,1)     48.021319330793595
wcss =   (1,1)      1.002600800365970

Elapsed time is 8.168377 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 16
Number of element in y-axis (8,12,16,20,24,...) = 16
Option (1,2,3 or 4) = 4

w_cn =   (1,1)     48.243914860248069
wcss =   (1,1)      1.007248204042067

Elapsed time is 10.047413 seconds.
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% ex3
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 4
Number of element in y-axis (8,12,16,20,24,...) = 4
Option (1,2,3,4 or 5) = 3

w_cn =   (1,1)     10.569771887710228
wcss =   (1,1)      0.105697718877102

Elapsed time is 5.880301 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 6
Number of element in y-axis (8,12,16,20,24,...) = 6
Option (1,2,3,4 or 5) = 3

w_cn =   (1,1)     11.654709948411140
wcss =   (1,1)      0.116547099484111

Elapsed time is 7.063141 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 8
Number of element in y-axis (8,12,16,20,24,...) = 8
Option (1,2,3,4 or 5) = 3

w_cn =  (1,1)     12.081219998962856
wcss =   (1,1)      0.120812199989629

Elapsed time is 6.650504 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 10
Number of element in y-axis (8,12,16,20,24,...) = 10
Option (1,2,3,4 or 5) = 3

w_cn =   (1,1)     12.286743257859641


wcss =   (1,1)      0.122867432578596

Elapsed time is 7.896279 seconds.
Main_Stiffened_Plate_HCT
Number of element in x-axis (8,12,16,20,24,...) = 12
Number of element in y-axis (8,12,16,20,24,...) = 12
Option (1,2,3,4 or 5) = 3

w_cn =   (1,1)     12.399878565483426
wcss =   (1,1)      0.123998785654834

Elapsed time is 8.794904 seconds.
