function g = gfun_square_plate_DSG_dyn(emodule_1,rho_1,poisson_1)
%emodule=2e11
%rho=8000
%poisson=0.3

emodule_1
rho_1
poisson_1

emodule = emodule_1(1);
rho = rho_1(1);
poisson = poisson_1(1);

tmp_u1 = square_plate_DSG_dyn(emodule,rho,poisson)
tmp_n  = size(tmp_u1,1)
%g  = ((tmp_u1(tmp_n)/92969)-1,1)
lamda_p=92969
g =  (tmp_u1(tmp_n,1))/lamda_p-1

%y1 = square_plate_DSG_dyn(emodule,rho,poisson)  
%y2 = 92969
%g =(y1/y2-1,1);

