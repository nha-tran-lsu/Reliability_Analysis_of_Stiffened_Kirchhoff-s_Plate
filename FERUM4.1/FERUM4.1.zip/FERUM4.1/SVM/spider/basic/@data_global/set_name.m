function [dat] = set_name(dat,nam)
 
%   data = set_name(data,name) sets the name of the data_global object to
%                              name
dat.algorithm.name=nam;
