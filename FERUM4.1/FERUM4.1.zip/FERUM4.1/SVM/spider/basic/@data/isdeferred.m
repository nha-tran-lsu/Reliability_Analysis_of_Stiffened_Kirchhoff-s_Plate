function y = isdeferred(a)

y = 0;
