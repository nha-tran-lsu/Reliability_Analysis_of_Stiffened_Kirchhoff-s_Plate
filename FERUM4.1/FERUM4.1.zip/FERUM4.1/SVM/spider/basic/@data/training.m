

function [dat,algo] =  training(algo,dat)
  %% return this, because this is data
  dat=algo;  
