function s=get_name(a)

s=['bayesian model selection'];
eval_name                   %% print values of hyperparameters
