function w =  get_w(a,d)  

w= (a.alpha' * a.child.dat.X)';

  
   
  
  
  
  
